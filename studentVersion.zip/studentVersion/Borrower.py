import json
import uuid
class Borrower:
    
    def display(self):
        print(f"Name: {self.__name}")
        print(f"Role: {self.__role}")
        print(f"ID: {self.__id}")

    def getName(self):
        return self.__name
    def getID(self):
        return self.__id
    def getRole(self):
        return self.__role
       