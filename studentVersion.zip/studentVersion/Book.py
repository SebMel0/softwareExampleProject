import uuid
class Book: 
    

    def getID(self):
        return self.__id
    
    def getName(self):
        return self.___title
    
    def getAuthor(self):
        return self.__author


# TEST
if __name__ == "__main__":
    new_novel = Book(title="Philosopher's Stone", author="J.K. Rowling",category="fiction")
    new_novel.display()